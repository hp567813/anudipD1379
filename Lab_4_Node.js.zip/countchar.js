const sentence1 = "Node.js makes JavaScript powerful on the server!";
const sentence2 = "Learning Node.js is fun and exciting.";
const sentence3 = "This is the third sentence for testing.";

console.log("character in sentence1 is:", sentence1.length);
console.log("character in sentence2 is:", sentence2.length);
console.log("character in sentence3 is:", sentence3.length);
